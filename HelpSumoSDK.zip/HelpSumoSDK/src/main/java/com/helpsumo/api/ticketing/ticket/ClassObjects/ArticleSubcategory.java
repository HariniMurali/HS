package com.helpsumo.api.ticketing.ticket.ClassObjects;

public class ArticleSubcategory {
    public String catgryid;
    public String catgryname;

    public ArticleSubcategory() {
    }

    public void setSubcatgryidId(String catgryid) {
        this.catgryid = catgryid;
    }

    public void setSubcatgryame(String catgryname) {
        this.catgryname = catgryname;
    }

    public String getSubcatgryid() {
        return catgryid;
    }

    public String getSubcatgryname() {
        return catgryname;
    }
}
