package com.helpsumo.api.ticketing.ticket.ClassObjects;

public class FaqCategoryDropdown {

    public String catgryid;
    public String catgryname;

    public FaqCategoryDropdown() {

    }

    public void setCatgryidId(String catgryid) {
        this.catgryid = catgryid;
    }

    public void setCatgryame(String catgryname) {
        this.catgryname = catgryname;
    }

    public String getCatgryid() {
        return catgryid;
    }

    public String getCatgryname() {
        return catgryname;
    }
}


