package com.helpsumo.api.ticketing.ticket.ClassObjects;

public class PriorityDropDown {

    public String priorId;
    public String priorName;

    public PriorityDropDown() {

    }

    public void setpriorId(String priorId) {
        this.priorId = priorId;
    }

    public void setpriorName(String priorName) {
        this.priorName = priorName;
    }


    public String getpriorId() {
        return priorId;
    }

    public String getpriorName() {
        return priorName;
    }
}
