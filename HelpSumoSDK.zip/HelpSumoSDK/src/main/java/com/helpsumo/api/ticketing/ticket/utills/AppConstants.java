package com.helpsumo.api.ticketing.ticket.utills;

public class AppConstants {
    public static String apikey = "";
    public static String d = "www.helpsumo.com/";
    public static String userId = "0";
    public static String TicketNo = "";
    public static String UserEmail = "";
    public static String h = "http://";
    public static String TicketSubject = "";
    public static String TicketMessage = "";
    public static String RequesterName = "";
    public static String li = "helpsumo/admin/";
    public static String DepartId = "";
    public static String TicketId = "";
    public static String PriorityId = "";
    public static String TypeId = "";
    public static String StaffId = "";
    public static String TicketStatus = "";
    public static String TicketDate = "";
    public static String TicketsModifiedDate = "";
    public static String url = h + d + li + "api/";
}
